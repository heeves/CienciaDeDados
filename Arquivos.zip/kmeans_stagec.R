require(survival)
library(e1071)
library(rpart)
library(class)
library(nnet)

# Clear workspace
rm(list = ls())

set.seed(1984)

if (any(is.na(stagec))) {
  cat("\n with NA ",nrow(stagec), " rows \n")
  stagec = na.omit(stagec)
  cat("\n without NA ",nrow(stagec), " rows \n")
} else cat("\n No NA values \n")

pred = kmeans(stagec[,-ncol(stagec)],3)

c_matrix = table(pred$cluster,stagec$ploidy)
print(c_matrix)

cat('Accuracy (?), not exactly...: ', sum(diag(c_matrix))/sum(c_matrix)*100, ' %', "\n")


